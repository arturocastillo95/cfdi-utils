PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO cce_tipos_operacion VALUES('2','Exportación');
COMMIT;
