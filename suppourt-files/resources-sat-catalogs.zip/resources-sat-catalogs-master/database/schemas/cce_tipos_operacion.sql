CREATE TABLE IF NOT EXISTS "cce_tipos_operacion"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
