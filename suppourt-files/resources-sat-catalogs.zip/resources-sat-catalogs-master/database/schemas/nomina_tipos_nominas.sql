CREATE TABLE IF NOT EXISTS "nomina_tipos_nominas"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
