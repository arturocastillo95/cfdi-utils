CREATE TABLE IF NOT EXISTS "cce_motivos_traslado"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
