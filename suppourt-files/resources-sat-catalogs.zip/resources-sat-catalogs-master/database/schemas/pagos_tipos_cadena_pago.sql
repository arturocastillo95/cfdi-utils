CREATE TABLE IF NOT EXISTS "pagos_tipos_cadena_pago"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
