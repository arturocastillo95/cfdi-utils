CREATE TABLE IF NOT EXISTS "nomina_tipos_contratos"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
