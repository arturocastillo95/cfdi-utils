PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO nomina_riesgos_puestos VALUES('1','Clase I','2017-01-01','');
INSERT INTO nomina_riesgos_puestos VALUES('2','Clase II','2017-01-01','');
INSERT INTO nomina_riesgos_puestos VALUES('3','Clase III','2017-01-01','');
INSERT INTO nomina_riesgos_puestos VALUES('4','Clase IV','2017-01-01','');
INSERT INTO nomina_riesgos_puestos VALUES('5','Clase V','2017-01-01','');
INSERT INTO nomina_riesgos_puestos VALUES('99','No aplica','2017-08-13','');
COMMIT;
