PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO ccp_20_tipos_servicio VALUES('TS01','Carros Ferroviarios','0','2021-12-01','');
INSERT INTO ccp_20_tipos_servicio VALUES('TS02','Carros Ferroviarios intermodal','1','2021-12-01','');
INSERT INTO ccp_20_tipos_servicio VALUES('TS03','Tren unitario de carros ferroviarios','0','2021-12-01','');
INSERT INTO ccp_20_tipos_servicio VALUES('TS04','Tren unitario Intermodal','1','2021-12-01','');
COMMIT;
