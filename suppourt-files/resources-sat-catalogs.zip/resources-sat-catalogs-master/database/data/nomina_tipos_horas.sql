PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO nomina_tipos_horas VALUES('01','Dobles');
INSERT INTO nomina_tipos_horas VALUES('02','Triples');
INSERT INTO nomina_tipos_horas VALUES('03','Simples');
COMMIT;
