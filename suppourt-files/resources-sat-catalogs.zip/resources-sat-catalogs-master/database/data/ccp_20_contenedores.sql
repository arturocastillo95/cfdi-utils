PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO ccp_20_contenedores VALUES('TC01','20''','Contenedor de 6.1 Mts de longitud','2021-06-01','');
INSERT INTO ccp_20_contenedores VALUES('TC02','40''','Contenedor de 12.2 Mts de longitud','2021-06-01','');
INSERT INTO ccp_20_contenedores VALUES('TC03','45''','Contenedor de 13.7 Mts de longitud','2021-06-01','');
INSERT INTO ccp_20_contenedores VALUES('TC04','48''','Contenedor de 14.6 Mts de longitud','2021-06-01','');
INSERT INTO ccp_20_contenedores VALUES('TC05','53''','Contenedor de 16.1 Mts de longitud','2021-06-01','');
COMMIT;
