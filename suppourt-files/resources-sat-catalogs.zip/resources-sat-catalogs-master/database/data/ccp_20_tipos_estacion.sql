PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO ccp_20_tipos_estacion VALUES('01','Origen Nacional','02, 03 y 04','2021-06-01','');
INSERT INTO ccp_20_tipos_estacion VALUES('02','Intermedia','02, 03 y 04','2021-06-01','');
INSERT INTO ccp_20_tipos_estacion VALUES('03','Destino Final Nacional','02, 03 y 04','2021-06-01','');
COMMIT;
