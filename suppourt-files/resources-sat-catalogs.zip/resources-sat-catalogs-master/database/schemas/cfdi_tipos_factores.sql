CREATE TABLE IF NOT EXISTS "cfdi_tipos_factores"("id" text not null, PRIMARY KEY("id"));
