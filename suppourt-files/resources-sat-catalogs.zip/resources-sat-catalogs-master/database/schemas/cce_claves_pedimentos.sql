CREATE TABLE IF NOT EXISTS "cce_claves_pedimentos"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
