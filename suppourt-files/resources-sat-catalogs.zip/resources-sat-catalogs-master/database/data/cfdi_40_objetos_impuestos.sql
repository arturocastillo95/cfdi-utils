PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO cfdi_40_objetos_impuestos VALUES('01','No objeto de impuesto.','2022-01-01','');
INSERT INTO cfdi_40_objetos_impuestos VALUES('02','Sí objeto de impuesto.','2022-01-01','');
INSERT INTO cfdi_40_objetos_impuestos VALUES('03','Sí objeto del impuesto y no obligado al desglose.','2022-01-01','');
COMMIT;
